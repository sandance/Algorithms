#!/usr/bin/python

Money=2000

def AddMoney():
	Money=Money+1
	print Money
	AddMoney()
	print Money


