from module_test import AddMoney


def print_func(par):
	print "Hello: ",par
	AddMoney()
	print Money
	return 


