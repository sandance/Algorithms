import hello

hello.print_func("Rashed")


