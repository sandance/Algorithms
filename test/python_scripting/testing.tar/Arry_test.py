Array=[]

import random

#The constructor is called to create the array

# Fill the array with random floating point

for i in :
	Array [i] = random.random()

#print the values , one per line
for values in Array:
	print(values)


